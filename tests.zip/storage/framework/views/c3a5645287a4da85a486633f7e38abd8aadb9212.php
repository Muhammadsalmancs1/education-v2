

<?php $__env->startSection('content'); ?>

<div class="content-wrapper px-lg-3 px-0">

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('registration.studentmanagment', ['mainsearch' => @$mainsearch])->html();
} elseif ($_instance->childHasBeenRendered('CLXXaAm')) {
    $componentId = $_instance->getRenderedChildComponentId('CLXXaAm');
    $componentTag = $_instance->getRenderedChildComponentTagName('CLXXaAm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CLXXaAm');
} else {
    $response = \Livewire\Livewire::mount('registration.studentmanagment', ['mainsearch' => @$mainsearch]);
    $html = $response->html();
    $_instance->logRenderedChild('CLXXaAm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  
</div>
<!-- / Layout page -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  window.addEventListener('close-model', event => {
  
          $('#followUp').modal('hide');
  
  });
  window.addEventListener('close-editmodel', event => {
  
  $('#view').modal('hide');

});
window.addEventListener('close-unilistmodel', event => {
  
  $('#action-uni').modal('hide');

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../admin/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\education-v2\resources\views/admin/registration/studentmanagement.blade.php ENDPATH**/ ?>