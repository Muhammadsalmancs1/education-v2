<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="<?php echo e(route('index')); ?>" class="">
            <img src="<?php echo e(asset('../admin/assets/img/logo (2).png')); ?>" alt="" class="">
        </a>
    </div>
    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboards -->
        <li class="menu-item <?php echo e(Route::currentRouteName() == 'index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('index')); ?>" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Dashboards">Dashboards</div>
            </a>

        </li>

        <!-- registration -->
        <li class="menu-item <?php echo e(Route::currentRouteName() == 'students_management' || Route::currentRouteName() == 'bookingleave_date' || Route::currentRouteName() == 'listing_counselor' || Route::currentRouteName() == 'country' || Route::currentRouteName() == 'agents' || Route::currentRouteName() == 'reference' || Route::currentRouteName() == 'sessions' || Route::currentRouteName() == 'subagent' ||Route::currentRouteName() == 'university' ? 'active open' : ''); ?>">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-copy"></i>
                <div data-i18n="Extended UI">Registration</div>
            </a>
            <ul class="menu-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Student Management')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'students_management' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('students_management')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Student Management</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Booking Management')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'bookingleave_date' ? 'active' : ''); ?> ">
                  <a href="<?php echo e(route('bookingleave_date')); ?>" class="menu-link">
                      <div data-i18n="Text Divider">Booking Management</div>
                  </a>
              </li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Currency')): ?>
                <li class="menu-item  <?php echo e(Route::currentRouteName() == 'listing_counselor' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('listing_counselor')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Currency</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Country')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'country' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('country')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Country</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Agent')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'agents' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('agents')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Agent</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Reference')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'reference' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('reference')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Reference</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Session')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'sessions' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('sessions')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Session</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Sub Agent')): ?>
                <li class="menu-item  <?php echo e(Route::currentRouteName() == 'subagent' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('subagent')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Sub Agent</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('University')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'university' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('university')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">University</div>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </li>


        <!-- Transection -->
        <li class="menu-item  <?php echo e(Route::currentRouteName() == 'counselor' ? 'active open' : ''); ?>">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-transfer"></i>

                <div data-i18n="Extended UI">Transection</div>
            </a>
            <ul class="menu-sub">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Assign Counselor')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'counselor' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('counselor')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Assign Counselor</div>
                    </a>
                </li>
                <?php endif; ?>

            </ul>
        </li>



        <!-- User Managementn -->
        <li class="menu-item <?php echo e(Route::currentRouteName() == 'user_page' || Route::currentRouteName() == 'roles' || Route::currentRouteName() == 'permissions' ? 'active open' : ''); ?>">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>

                <div data-i18n="Extended UI">User Management</div>
            </a>
            <ul class="menu-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Users')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'user_page' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('user_page')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Users</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Users Access Role')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'roles' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('roles')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Users Access Role</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Users Permissions')): ?>
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'permissions' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('permissions')); ?>" class="menu-link">
                        <div data-i18n="Text Divider">Users Permissions</div>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </li>

       <!-- Expense -->
        <li class="menu-item">
            <a href="" class="menu-link ">
                <i class="menu-icon tf-icons bx bx bx-copy"></i>
               Expense
            </a>

        </li>

    </ul>
</aside>


<script>
     function toggleDropdown(element) {
        // Toggle active class when the dropdown is clicked
        element.parentNode.classList.toggle('active');
    }
</script>
<?php /**PATH C:\xampp\htdocs\education-v2\resources\views////admin/layout/sidebar.blade.php ENDPATH**/ ?>