<div>
    <div>

        <div class="card  pb-4 px-lg-4 px-2">
            <div class="mt-2 d-flex  justify-content-between  align-items-center ">

            <h5 class="card-header px-0 bg-white border-bottom-0  py-3 mb-2 ">Users Roles</h5>
            <button type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop"
                class="edit-data py-2 mt-3">Add Roles</button></div>
            <table id="assign" class="table  nowrap border-0 " style="width:100%">
                <thead>
                    <tr class="dt-head">
                        <th class="text-center">#</th>
                        <th>Role </th>
                        <th >Actions</th>
                    </tr>

                </thead>
                <tbody>
                  <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($key+1); ?></td>
                        <td><?php echo e($item->name); ?></td>

                        <td>
                          <div class="d-flex align-items-center">
                            <button type="button" class="edit-data"
                            data-bs-toggle="modal" data-bs-target="#access" wire:click="assigncontrol(<?php echo e($item->id); ?>)">
                            Access Controls
                        </button>
                            <button type="button" wire:click="editRecord(<?php echo e($item->id); ?>)" data-bs-toggle="modal" data-bs-target="#Editmodel"
                              class="edit-data">Edit</button>
                            <button class="delete-data" wire:click="confirmDelete(<?php echo e($item->id); ?>)">Delete</button>
                          </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div>
              <?php echo e($show->links()); ?>

            </div>
        </div>


        <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Add Role </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" wire:click="closemodel" aria-label="Close"></button>
      </div>
      <form action="" wire:submit="saverole">
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname">Role</label>
            <input type="text" class="form-control" id="basic-default-fullname" wire:model="role" placeholder="Enter Role"
              value="" />
              <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" wire:click="closemodel">Close</button>
          <button type="button" class="btn btn-primary" wire:click="saverole">Save</button>
        </div>
      </form>
    </div>
    </div>
    </div>

        <!-- Edit Modal -->
        <div class="modal fade" id="Editmodel" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Edit Role </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" wire:click="closemodel" aria-label="Close"></button>
          </div>
          <form action="" wire:submit="updateRecord">
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label" for="basic-default-fullname">Role</label>
                <input type="text" class="form-control" id="basic-default-fullname" wire:model="role" placeholder="Enter Role"
                  value="" />
                  <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" wire:click="closemodel">Close</button>
              <button type="button" class="btn btn-primary" wire:click="updateRecord">Save</button>
            </div>
          </form>
        </div>
        </div>
        </div>
    </div>

    

    <div class="modal fade" id="access" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-fullscreen modal-dialog-centered" style="height: auto;">
        <div class="modal-content ">
            <div class="modal-header modal-header-style">
                <h5 class="modal-title mb-3 text-white " id="staticBackdropLabel">Acess Control</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="my-4 mx-4">
              <?php $__currentLoopData = $datalistingpermission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <span class=" mx-2 my-3 py-2" > <?php echo e($item->name); ?>  <button type="button" class="btn-close px-2" style="font-size:12px;" wire:click="removepermission(<?php echo e($item->id); ?>)" ></button></span>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <form action="" wire:submit="Assignpermissions" wire:ignore.self>
                <div class="modal-body">
                    <div class="container ">
                        <div class="row">
                            <div class="table-responsive">
                                <table class="table table-bordered" style="min-width: 700px;" >
                                    <thead>

                                        <tr class="dt-head">
                                            <th scope="col">Permission Name</th>
                                            <th scope="col" class="text-center">Assign</th>
                                        </tr>
                                    </thead>
                                    <tbody class="">

                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <tr class="">

                                            <td class="">
                                                <?php echo e($item->name); ?>

                                            </td>
                                            <td>
                                                <div class="d-flex justify-content-center">
                                                    <input type="checkbox" class="" value="<?php echo e($item->name); ?>" wire:model="permissiongive.<?php echo e($item->id); ?>">
                                                </div>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-warning" data-bs-dismiss="modal" aria-label="Close">Close</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" wire:click="Assignpermissions">Submit</button>
                    <!-- <button type="button" class="btn btn-primary">Save</button> -->
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\education-v2\resources\views/livewire/rolesandpermission/user-roles.blade.php ENDPATH**/ ?>